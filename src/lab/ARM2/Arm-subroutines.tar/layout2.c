int num1=1, num2=1, sum1=1;

main()
{
  sum();
}

sum()
{
  num1 = 1;
  num2 = 2;
  sum1 = num1 + num2;
}
