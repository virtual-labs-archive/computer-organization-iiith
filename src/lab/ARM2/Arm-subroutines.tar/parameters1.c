main()
{
  int retsum;
  retsum = sum(1, 3);
}

int sum(int numA, int numB)
{
  int temp;
  temp = numA + numB;
  return temp;
}
