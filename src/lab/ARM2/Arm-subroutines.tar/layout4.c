main()
{
  sum();
}

sum()
{
  int num1, num2;
  static int sum1=1;
  num1 = 1;
  num2 = 2;
  sum1 = num1 + num2;
}
