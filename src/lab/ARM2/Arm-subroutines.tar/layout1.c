main()
{
  sum();
}

sum()
{
  int num1, num2, sum1;
  num1 = 1;
  num2 = 2;
  sum1 = num1 + num2;
  sum();
}
